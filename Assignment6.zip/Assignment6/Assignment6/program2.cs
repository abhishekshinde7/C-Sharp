﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    class Program2
    {
        /// <summary>
        /// Searchs Perticular Element in Array
        /// </summary>
        /// <param name="a">Array</param>
        /// <param name="n">Element to be Searched</param>
        /// <returns></returns>
     public   string SearchArray(int[][] a,int n)
        {
            
            for(int i = 0; i < a.Length; i++)
            {
                foreach (int temp in a[i])
                {
                    if (temp == n)
                    {
                        return "found";
                    }
                }
            }
            return "not found";
        }
        static void Main()
        {
            Console.WriteLine("enter a number to search");
           int n= Convert.ToInt32(Console.ReadLine());
            int[][] arr = new int[3][];
            arr[0] = new int[] {1,2,3,4,5};
            arr[1] = new int[] { 6, 7, 8 };
            arr[2] = new int[] { 9,10 };

            Program2 p = new Program2();
            Console.WriteLine($"{n}:{p.SearchArray(arr,n)}");
            Console.ReadLine();
        }
    }
}
