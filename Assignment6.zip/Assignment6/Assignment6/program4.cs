﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    class Program4
    {
       /// <summary>
       /// Out Parameter Function which returns Simple INterst Amount And total Amount as Out Parameter
       /// </summary>
       /// <param name="tamt">Total Amount</param>
       /// <param name="amt">Amount</param>
       /// <param name="mnth">Month</param>
       /// <returns></returns>
        static double simple(out double tamt,double amt,int mnth){
             tamt = (amt * 5 * mnth / 100)+amt;
            return (amt * 5 * mnth / 100);
        }
        static void Main()
        {
            Console.WriteLine("enter amount");
            double tamt;
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter months");
            int mnth = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($" simple interest ={simple(out tamt,amt,mnth) } total payable amount={ tamt}");
            Console.ReadLine();
        }

    }
}
