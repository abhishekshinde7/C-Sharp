﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    class Program5
    {/// <summary>
    /// returns gst Amount 
    /// is a Default Parameter Function
    /// </summary>
    /// <param name="amt">Amount</param>
    /// <param name="gst">Default Value=1</param>
    /// <returns></returns>
        static double gst(double amt,double gst=1){
            
            return amt*gst/100;
            }
       static void Main()
        {
            Console.WriteLine("enter amount");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"gst Amount={gst(amt)}");
           Console.ReadLine();
        }
    }
}
