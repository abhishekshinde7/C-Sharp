﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
   
    class Program1
    {/// <summary>
    /// Returns Factorial 
    /// </summary>
    /// <param name="n">int Paratmeter</param>
    /// <returns></returns>
public int fact(int n)
        {
            int factP = 1;
            for(int i = n; i > 0; i--)
            {
                factP = factP * i;
            }
            return factP;
        }
        static void Main()
        {
            Program1 p = new Program1();
            Console.WriteLine("Enter a number");
            Console.WriteLine($"factorial is {p.fact(Convert.ToInt32(Console.ReadLine()))} ");
            Console.ReadLine();
        }
    }
}
