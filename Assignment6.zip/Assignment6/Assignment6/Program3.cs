﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    class Program3
    {
        /// <summary>
        /// Calculates Simple Interest and returns total Amount
        /// </summary>
        /// <param name="amt">Amount</param>
        /// <param name="mnth">Months</param>
        /// <returns></returns>
        static double SimpleInt(double amt,int mnth)
        {
            double Tamt = amt * 5 * mnth / 100;
            return Tamt;
        }
        
        static void Main()
        {
            Console.WriteLine("enter amount");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter months");
            int mnth = Convert.ToInt32(Console.ReadLine());
               Console.WriteLine($"{SimpleInt(amt,mnth)}");
            Console.ReadLine();
        }
    }
}
