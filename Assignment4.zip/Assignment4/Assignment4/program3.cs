﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class program3
    {
        static void Main()
        {
            int[] a = new int[50];
            for(int i = 0; i < 50; i++)
            {
                a[i] = i+1;
            }
            foreach(int i in a){
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}
