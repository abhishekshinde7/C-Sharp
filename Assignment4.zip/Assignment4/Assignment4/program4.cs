﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class program4
    {
        static void Main()
        {
            Console.WriteLine("enter size of array");
            int size=Convert.ToInt32(Console.ReadLine());
            int[] a = new int[size];
            Console.WriteLine("enter elemnts in array");
            for (int i = 0; i < size; i++)
            {
                a[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("even nos in array");
            foreach (int i in a)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine(i);
                }
            }
            Console.ReadLine();
        }
    }
}
