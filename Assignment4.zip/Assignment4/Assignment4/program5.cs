﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class program5
    {
        static void Main()
        {
            Console.WriteLine("Enter a number for table");
            int num = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("{0} * {1}={2}",num,i,num*i);
            }
            Console.ReadLine();
        }
    }
}
