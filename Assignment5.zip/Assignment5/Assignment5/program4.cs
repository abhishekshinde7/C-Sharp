﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class program4
    {
        static void Main()
        {
            int[,] a = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
            for(int r = 0; r < 3; r++)
            {
                int sum = 0;
                for(int c = 0; c < 3; c++)
                {
                    sum = sum + a[r, c];
                }
                Console.WriteLine(sum);
            }
            Console.ReadLine();
        }
    }
}
