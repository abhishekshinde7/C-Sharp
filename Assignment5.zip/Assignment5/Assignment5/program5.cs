﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class program5
    {
        static void Main()
        {
            
            int count = 0;
            for(char ch ='a'; ch <= 'i'; ch++)
            {
                Console.Write("{0}\t",Convert.ToInt32(ch));
                count++;
                if (count == 3)
                {
                    Console.WriteLine();
                    count = 0;
                }
            }
            Console.ReadLine();
        }
    }
}
