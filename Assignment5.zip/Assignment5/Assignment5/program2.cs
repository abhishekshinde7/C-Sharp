﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class program2
    {
        static void Main()
        {
            int[,] a = { {10,40,50 },{60,20,70 },{80,90,30 } };
            int rows = a.GetUpperBound(0);
            int cols = a.GetUpperBound(1);
            int sum = 0;
            
            for (int r=0;r<3;r++)
            {
                for (int c = 0; c < 3; c++)
                {
                    if (c == r)
                    {
                        //Console.WriteLine("sum"+sum+","+r+c);
                        sum = sum + a[r, c];
                    }
                }
            }
            Console.WriteLine(sum);
            Console.ReadLine();
        }
    }
}
