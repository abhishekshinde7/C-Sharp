﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Assignment2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a char");
            char ch = Convert.ToChar(Console.ReadLine());
            int a = (int)ch;
            Console.WriteLine("ascii={0}", a);
            Console.WriteLine("enter a integer");

            int b = Convert.ToInt32(Console.ReadLine());
            char ch1 = (char)b;
            Console.WriteLine("char= {0}", ch1);
            Console.ReadLine();
        }
    }
}
