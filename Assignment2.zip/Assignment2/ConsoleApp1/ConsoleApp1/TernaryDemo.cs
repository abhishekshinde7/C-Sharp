﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class TernaryDemo
    {
        static void Main()
        {
            Console.WriteLine("enter annual Income");
            int income = Convert.ToInt32(Console.ReadLine());
            string result = income >= 250000 ? "you are Income tax" : "no Income Tax";
            Console.WriteLine(result);
        }
    }
}
