﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Assignment3
    {/// <summary>
    /// Converts Dollars in Rupees
    /// </summary>
    /// <param name="dollar">Dollar</param>
        void inRupees(double dollar)
        {
            int rs = Convert.ToInt32(dollar * 70);
            Console.WriteLine("{0} in rupees={1}", dollar, rs);
        }
        /// <summary>
        /// Converts Rupees in Dollars
        /// </summary>
        /// <param name="rs">RS</param>
        void inDollar(int rs)
        {
            double dollar = Convert.ToDouble(rs/70);
            Console.WriteLine("{0} in dollars={1}", rs,dollar);
        }



        static void Main(string[] args)
        {
            Console.WriteLine("enter dollars:");
            double dollar =Convert.ToDouble(Console.ReadLine());
            
            Assignment3 a = new Assignment3();
            a.inRupees(dollar);
            Console.WriteLine("enter rupess:");
            int rs = Convert.ToInt32(Console.ReadLine());
            a.inDollar(rs);
            
            Console.ReadLine();
        }
    }
}
