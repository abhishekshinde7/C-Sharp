﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Assignment1
    {
        const double pi = 3.14;
        void area(int r)
        {
            Console.Write(r * r * pi);
            Console.ReadLine();
        }
        static void Main(string[] args)
        {
            Assignment1 p = new Assignment1();
           
            p.area(Convert.ToInt32(Console.ReadLine()));
        }
    }
}
