﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Program2
    {
       /// <summary>
       /// Prints Grade according to percentage
       /// </summary>
       /// <param name="percentage">percentage</param>
        public void GradeCalc(double percentage)
        {
            if (percentage >= 80)
            {
                Console.WriteLine("grade is A");
            }
            else if (percentage >= 60)
            {
                Console.WriteLine("grade is b");
            }
            else if (percentage >= 50)
            {
                Console.WriteLine("grade is c");
            }
            else if (percentage >= 35)
            {
                Console.WriteLine("grade is d");
            }
            else
            {
                Console.WriteLine("Failed");

            }
        }
        static void Main()
        {
            Console.WriteLine("enter percentage:");
            double percentage= Convert.ToDouble(Console.ReadLine());
            Program2 p = new Program2();
            p.GradeCalc(percentage);
            Console.ReadLine();
        }

        }
    }

