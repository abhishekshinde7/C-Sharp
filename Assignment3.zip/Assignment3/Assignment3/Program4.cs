﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Program4
    {
        static void Main()
        {
            Console.WriteLine("Enter age:");

            int age = Convert.ToInt32(Console.ReadLine());
            bool b= age >= 18;
          //ternary operator use
            Console.WriteLine("person is {0}",b?"Major":"Minor");
            Console.ReadLine();
        }
    }
}
