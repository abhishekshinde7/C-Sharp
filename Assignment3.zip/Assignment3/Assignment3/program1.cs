﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Program1
    {
        /// <summary>
        /// Prints if the person is major or minor
        /// </summary>
        /// <param name="age">age</param>
        public void Age(int age)
        {
            if (age >= 18)
            {
                Console.WriteLine("Person is major");
            }
            else
            {
                Console.WriteLine("Person is minor");
            }
           
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter age:");
        
        int age = Convert.ToInt32(Console.ReadLine());
            Program1 p = new Program1();
            p.Age(age);
            Console.ReadLine();


        }
    }
}
