﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodDemo
{
    class ExtensionMethodDemo
    {
        static void Main()
        {
            int i = 400;
            bool result = i.isGreaterThan(100);
            Console.WriteLine(result);
            Console.WriteLine(result ? "Greater" : "smaller");

            Console.WriteLine(i.isPositiveOrNot(7));
            Console.ReadLine();
        }
    }
	
    public static class IntExtension
    {
        /// <summary>
        /// Compares Value
        /// </summary>
        /// <param name="i"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool isGreaterThan(this int i,int value)
        {
            return i > value;
        }
    }
    public static class IntExtension2
    {
        /// <summary>
        /// Checks if the number is positive or not
        /// </summary>
        /// <param name="i"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool isPositiveOrNot(this int i,int value)
        {
            if (i >=0)
            {
                Console.WriteLine(value+i);
                return true;
            }
            else
            {
                Console.WriteLine("negative");
                return false;
            }
           
        } 
    }
}
