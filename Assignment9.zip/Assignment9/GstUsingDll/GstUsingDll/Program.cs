﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GST;
namespace GstUsingDll
{
    class Program
    {
        static void Main(string[] args)
        {
            Gst g = new Gst();
          

            Console.WriteLine("GST CALCULATION APPLICATION--------");
            Console.WriteLine("Enter Amount");
            double amt = Convert.ToDouble((Console.ReadLine()));

  EnterCh:  Console.WriteLine("Choose Gst Rate");
            Console.WriteLine("1:0%");
            Console.WriteLine("2:5%");
            Console.WriteLine("3:12%");
            Console.WriteLine("4:18%");
            Console.WriteLine("5:28%");
            string ch = Console.ReadLine();
            double gstRate=0;
           
            switch (ch)
            {
                case "1":gstRate = (double)gstSlab.Slab1;
                    break;
                case "2":
                    gstRate = (double)gstSlab.Slab2;
                    break;
                case "3":
                    gstRate = (double)gstSlab.Slab3;
                    break;
                case "4":
                    gstRate = (double)gstSlab.Slab4;
                    break;
                case "5":
                    gstRate = (double)gstSlab.Slab5;
                    break;

                default:
                    Console.WriteLine("Wrong Choice!!! ");
                    goto EnterCh;
                    
            }
           
          
            double GstAmt;
            Console.WriteLine($"Total Amount:{g.getGst(out GstAmt, amt, gstRate)} gstamt:{GstAmt}");
            Console.ReadLine();
        }
    }
}
