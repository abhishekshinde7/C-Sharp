﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigntment7
{
    class Program2
    {
        static void Main()
        {
           foreach(string s in Enum.GetNames(typeof(city)))
            {
                Console.WriteLine($"city={s}");
            }
            foreach (int s in Enum.GetValues(typeof(city)))
            {
                Console.WriteLine($"std={s}");
            }
            Console.ReadLine();

        }
    }
    enum city
    {
        mumbai=1,pune=2,solapur=3,banglore=4
    }
}
