﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigntment7
{
    class Program1
    {
        static void Main()
        {
            student s = new student(1,2332434,"Abhishek","male");
            s.display();
            Console.ReadLine();
        }
    }
    /// <summary>
    /// Structure Student
    /// </summary>
    struct student
    {
        int rollno, mobileno;
        string name, gender;
        public student(int rollno,int mobileno, string name, string gender)
        {
            this.rollno = rollno;
            this.mobileno = mobileno;
            this.name = name;
            this.gender = gender;
        }
        /// <summary>
        /// Display Method which Displays the Data of Student
        /// </summary>
        public void display()
        {
            Console.WriteLine($"rollno:{this.rollno} \n mobileno:{this.mobileno} \n name:{ this.name } \n gender:{this.gender}");
        }

    }
}
