﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class Program5Bank
    {
        static void Main()
        {
            CurrentAccount ca = new CurrentAccount(10000000);
            SavingAccount sa = new SavingAccount(1000000);
            Program5Bank pb = new Program5Bank();
           
            int Flag = 0;
            do
            {
                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                invalChoice: Console.WriteLine(" Enter 1:SAVING ACCOUNT \n Enter 2:CURRENT ACCOUNT \n Enter 3:EXIT \n Enter Your Choice :");
                string ch = Console.ReadLine();
                switch (ch)
                {
                    case "1":
                        Console.WriteLine("In saving account-----");
                        pb.BankingSavingAcc(sa);
                        break;
                    case "2":
                        Console.WriteLine("In current account-----");
                        pb.BankingCurrentAcc(ca);
                        break;
                    case "3":
                        Flag++;
                        break;
                    default:
                        Console.WriteLine("Invalid choice!!!");
                        goto invalChoice;

                }
            } while (Flag == 0);
        }
        /// <summary>
        /// Banking method for SavingAccount 
        /// </summary>
        /// <param name="sa">SavingAccount object</param>
        void BankingSavingAcc(SavingAccount sa)
        {
            invalChoice: Console.WriteLine(" Enter 1:Deposit \n Enter 2:Withdraw ACCOUNT \n Enter Your Choice :");
            string ch = Console.ReadLine();
            switch (ch)
            {
                case "1":
                    Console.WriteLine("Enter Amount to Deposit:");
                    double amt = Convert.ToDouble(Console.ReadLine());
                    sa.Deposit(amt);
                    Console.WriteLine();
                    break;
                case "2":
                    Console.WriteLine("Enter Amount to Withdraw:");
                    double amt1 = Convert.ToDouble(Console.ReadLine());
                    sa.Withdraw(amt1);
                    Console.WriteLine();
                    break;
                default:
                    Console.WriteLine("Invalid choice!!!");
                    goto invalChoice;

            }
        }
        /// <summary>
        /// banking method for CurrentAccount
        /// </summary>
        /// <param name="ca">CurrentAccount object</param>
        void BankingCurrentAcc(CurrentAccount ca)
        {
            invalChoice: Console.WriteLine(" Enter 1:Deposit \n Enter 2:Withdraw ACCOUNT \n Enter Your Choice :");
            string ch = Console.ReadLine();
            switch (ch)
            {
                case "1":
                    Console.WriteLine("Enter Amount to Deposit:");
                    double amt = Convert.ToDouble(Console.ReadLine());
                    ca.Deposit(amt);
                    break;
                case "2":
                    Console.WriteLine("Enter Amount to Withdraw:");
                    double amt1 = Convert.ToDouble(Console.ReadLine());
                    ca.Withdraw(amt1);
                    break;
                default:
                    Console.WriteLine("Invalid choice!!!");
                    goto invalChoice;

            }
        }
    }
    interface IBankAccount
    {
        void Deposit(double amount);
        void Withdraw(double amount);
    }
    class SavingAccount : IBankAccount
    {
        double bal ;
        public SavingAccount(double bal)
        {
            this.bal = bal;
        }
        /// <summary>
        /// deposit method for Saving Acc
        /// </summary>
        /// <param name="amount">Amount</param>
        public void Deposit(double amount)
        {
            bal += amount;
            Console.WriteLine($"Amount Deposited : {amount} and SavingAcc Balance is {bal}");
        }
        /// <summary>
        /// withdraw method saving acc
        /// </summary>
        /// <param name="amount">amount</param>
        public void Withdraw(double amount)
        {
            if (bal >= amount)
            {
                bal -= amount;
                Console.WriteLine($"SavingAcc Balance is:{bal}");
            }
            else
            {
                Console.WriteLine($"SavingAcc Balance is low!,:{bal} cannot withdraw amount :{amount}!!");

            }

        }
    }
    class CurrentAccount : IBankAccount
    {
        double bal;
        public CurrentAccount(double bal)
        {
            this.bal = bal;
        }
        /// <summary>
        /// deposit method for current Acc
        /// </summary>
        /// <param name="amount">amount</param>
        public void Deposit(double amount)
        {
            bal += amount;
            Console.WriteLine($"Amount Deposited : {amount} and CurrentAcc Balance is {bal}");
        }
        /// <summary>
        /// withdraw method for cuurent acc
        /// </summary>
        /// <param name="amount">amount</param>
        public void Withdraw(double amount)
        {
            if (bal>=amount) {
                bal -= amount;
                Console.WriteLine($"CurrentAcc Balance is:{bal}");
            }
            else
            {
                Console.WriteLine($"CurrentAcc Balance is low!,balance:{bal}  cannot withdraw amount :{amount}!!");

            }
        }
    }



}
