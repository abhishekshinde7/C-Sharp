﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class Program2
    {
        static void Main()
        {
            Pen p = new Pen();
            p.StartWriting();
            p.StopWriting();
            Console.ReadLine();
        }
    }
    sealed public class Pen
    {
        /// <summary>
        /// starts writing
        /// </summary>
        public void StartWriting()
        {
            Console.WriteLine("starts writing");
        }
        /// <summary>
        /// stops writing
        /// </summary>
        public void StopWriting()
        {
            Console.WriteLine("stops writing");
        }
    }

}
