﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class Program1
    {

        static void Main(string[] args)
        {
            SuperComputer s = new SuperComputer();
            s.BootUp();
            s.ShutDown();
            MainFrameComputer mf = new MainFrameComputer();
            mf.BootUp();
            mf.ShutDown();
            MicroComputer mc = new MicroComputer();
            mc.BootUp();
            mc.ShutDown();
            Console.ReadLine();
        }
    }
    /// <summary>
    /// abstract class Computer
    /// </summary>
    abstract public class Computer
    {
        /// <summary>
        /// Bootups Computer
        /// </summary>
        public void BootUp()
        {
            Console.WriteLine("Booting up");
        }
       
        abstract public void ShutDown();
        
    }
    /// <summary>
    /// inherits abstract class Computer
    /// </summary>
    public class SuperComputer : Computer
    {
        /// <summary>
        /// shuts Down Computer
        /// </summary>
        public override void ShutDown()
        {
            Console.WriteLine("Shutting Down SuperComputer");
        }
       
    }
    /// <summary>
    /// inherits abstract class Computer
    /// </summary>
    public class MainFrameComputer : Computer
    {
        /// <summary>
        /// shuts Down MainFrameComputer
        /// </summary>
        public override void ShutDown()
        {
            Console.WriteLine("Shutting Down MainFrameComputer");
        }

    }
    /// <summary>
    /// inherits abstract class Computer
    /// </summary>
    public class MicroComputer : Computer
    {
        /// <summary>
        /// shuts Down MicroComputer
        /// </summary>
        public override void ShutDown()
        {
            Console.WriteLine("Shutting Down MicroComputer");
        }

    }
}
