﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class Program3Hotel
    {
        static void Main()
        {
            Console.WriteLine("Enter room number");
            int number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter floor");
            int floor = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Room Capacity");
            int capacity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Room Type");
            string type = Console.ReadLine();
            Console.WriteLine("Enter bookedtime (format:dd/mm/yyyy hh/mm)");
            DateTime bookedTime = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter Price");
            double price = Convert.ToDouble(Console.ReadLine());
            Room rm = new Room(number, floor, capacity, type, bookedTime, price);
            Console.WriteLine(rm.ToString());
            Console.ReadLine();
        }
    }
    public class Room
    {
        private int number, floor, capacity;
        private string type;
        private DateTime bookedTime;
        private double price;

       public Room(int number, int floor, int capacity, string type, DateTime bookedTime, double price)
        {
            this.number = number;
            this.floor = floor;
            this.capacity = capacity;
            this.type = type;
            this.bookedTime = bookedTime;
            this.price = price;
        }
        /// <summary>
        /// overided tostring method to print object data
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return string.Format($"Room number:{number} \n floor:{floor} \n capacity:{capacity} type:{type} bookedtime:{bookedTime} price:{price}");
        }


    }
}
