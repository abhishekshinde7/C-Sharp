﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class Program4Forum
    {
        static void Main()
        {   
            //List of User Objects
            List<User> userlist = new List<User>();
            //for loop control
            int flag = 0;
            do
            {
                InvalidChoice: Console.WriteLine("^^^^^^^^^^^User Registration^^^^^^^^^^^");       //goto point
                Console.WriteLine("Enter 1:New User Registration");
                Console.WriteLine("Enter 2:Exit");
                string ch = Console.ReadLine();
                switch (ch)
                {
                    case "1":
                        UserRegMethods ur = new UserRegMethods();
                        userlist=ur.Registration(userlist);
                        break;
                    case "2":
                        flag++;
                        break;
                    default:
                        goto InvalidChoice;
                       
                }
            }
            while (flag == 0);
           
        }
    }
    public class User
    {
        private long id;
        private String name, emailid;
        private DateTime dateofbirth;

        public long Pid
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }
        public string Pname
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public string Pemailid
        {
            get
            {
                return emailid;
            }
            set
            {
                emailid = value;
            }
        }
        public DateTime Pdateofbirth
        {
            get
            {
                return dateofbirth;
            }
            set
            {
                dateofbirth = value;
            }
        }

        public override string ToString()
        {
            return $"-------USER DETAILS:---------- \n ID:{id} \n NAME:{name} \n EMAILID:{emailid} \n DOB:{dateofbirth} \n User Registered SuccessFully!! :) \n" ;
        }
    }
    public class UserRegMethods
    {
        /// <summary>
        /// User registration Method
        /// </summary>
        /// <param name="userlist">UserObject List</param>
        /// <returns></returns>
        public List<User> Registration(List<User> userlist)
        {
            User userObj = new User();
            Console.WriteLine("Enter EmailId");

  invalidMailID: String emailid = Console.ReadLine();
           
            //validating Email
            if (!validateEmail(userlist, emailid))
            {
                Console.WriteLine("EmailId Already Exists!! Enter a new one:");
                goto invalidMailID;
            }
            //entering user data in User class object
            userObj.Pemailid = emailid;
            Console.WriteLine("Enter Id");
            userObj.Pid =Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("Enter Name");
            userObj.Pname = Console.ReadLine();
            Console.WriteLine("Enter Date OF Birth (format eg:DD/MM/YYYY)");
            userObj.Pdateofbirth =Convert.ToDateTime( Console.ReadLine());

            Console.WriteLine(userObj.ToString());
            userlist.Add(userObj);
           
            return userlist;
        }
        /// <summary>
        /// validate email 
        /// </summary>
        /// <param name="userlist">UserObject List</param>
        /// <param name="emailid">EmailID</param>
        /// <returns></returns>
        static bool validateEmail(List<User> userlist,string emailid)
        {
            foreach (User u in userlist)
            {
                if (u.Pemailid==emailid)
                {
                    return false;
                }
            }
            return true;
        }
        
    }

}
